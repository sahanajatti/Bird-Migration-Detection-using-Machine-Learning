// script.js

document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.csv';
    fileInput.addEventListener('change', handleFileUpload);

    const predictedTableBody = document.getElementById('predicted-table-body');
    const predictedTableContainer = document.getElementById('predicted-table-container');
    predictedTableContainer.appendChild(fileInput);

    function handleFileUpload(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.readAsText(file);
            reader.onload = function(event) {
                const csv = event.target.result;
                const rows = csv.split('\n');
                predictedTableBody.innerHTML = ''; // Clear previous data

                for (let i = 1; i < rows.length; i++) { // Start from 1 to skip header
                    const columns = rows[i].split(',');
                    if (columns.length >= 19) { // Ensure there are at least 19 columns
                        const birdName = columns[1].trim(); // bird_name
                        const longitude = columns[9].trim(); // longitude
                        const latitude = columns[8].trim(); // latitude
                        const country = columns[4].trim(); // COUNTRY
                        const PREDICTED_BIRD_NAME_DT = columns[23].trim(); // PREDICTED_BIRD_NAME_DT
                        const row = `<tr><td>${birdName}</td><td>${longitude}</td><td>${latitude}</td><td>${country}</td><td>${PREDICTED_BIRD_NAME_DT}</td></tr>`;
                        predictedTableBody.insertAdjacentHTML('beforeend', row);

                    }
                }
            };
        }
    }
});
